<?php
$conn = new mysqli("localhost", "root", "", "leavemanager");

$lid = $_GET['lid'];
$query="UPDATE `leavetable` SET `status`='Approved' WHERE `lid`='$lid'";
$result = mysqli_query($conn, $query);
header('Location:adminviewpending.php');
?>
