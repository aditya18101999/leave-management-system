<!DOCTYPE html>

<html>
<?php
        session_start();
        echo $_SESSION['username'];
        $uid=$_SESSION['uid'];
        $conn = new mysqli("localhost", "root", "", "leavemanager");




        $query="SELECT SUM(`numdays`) AS 'sumdays' FROM `leavetable` WHERE `uid`='$uid'";
        $result=mysqli_query($conn,$query);
        $row=mysqli_fetch_array($result);
        if ($row['sumdays']>20) {
            header('Location:maxreached.php');
        }





        
        // echo $_SESSION['cusid'];
        ?>

<head>
    <title>Leave Manager</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="box">
        <div class="card">
            <h1 class="label">Apply Leave Form</h1>
            <form action="applyleaveinsert.php" method="POST">
                <table>
                    <tr>
                        <p style="color:red;">
                            <?php
                            if (isset($_GET['error'])) {
                                $error = $_GET['error'];

                                echo $error;
                                
                            }
                            ?>
                        </p>
                    </tr>
                    <tr>
                        <td>Startdate :</td>
                        <td><input type="date" name="startdate" required /></td>
                    </tr>
                    <tr>
                        <td>Number of days :</td>
                        <td><input type="number" name="numdays" min="1" max="100" required /></td>
                    </tr>
                    
                    <tr>
                        <td>Reason :</td>
                        <td>
                        <textarea name="reason" required>

                        </textarea></td>
                    </tr>


                    </tr>
                    <tr>
                        <td></td>
                        <td><input class="button" type="submit" value="Submit" /></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>

</body>

</html>