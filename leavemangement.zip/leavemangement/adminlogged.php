<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Leave manager</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="box">
        <p class="large bold upper">welcome 
    <?php
        session_start();
        echo $_SESSION['username'];
        // echo $_SESSION['cusid'];
        ?>
    </p>

        <div>
            <a href="adminviewpending.php"><button class="button">View Pending</button></a>

            <br><br>
        </div>

        <div>
            <a href="adminviewall.php"><button class="button">View all</button></a>

            <br><br>
        </div>
         
        
    </div>
</body>
</html>