<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Leave Manager</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    
<?php
    session_start();
    session_destroy();
    ?>
    
    <div class="box">
        <div class="card">
        <h1 class="label">LOGIN</h1>
        <form action="loginauth.php" method="POST">
            <table>
                <tr>
                    <td>userid :</td>
                    <td><input type="text" name="username" required /></td>
                </tr>
                <tr>
                <p style="color:red;">
                        <?php
                        if (isset($_GET['error'])) {
                            $error = $_GET['error'];

                            echo $error;
                        }
                        ?>
                    </p>
                </tr>
                <tr>
                    <td>password :</td>
                    <td><input type="password" name="password" required /></td>
                </tr>
                    </div>
                <tr>
                    <td></td>
                    <td><input class="button" type="submit" value="Submit" /></td>
                </tr>
            </table>
        </form>
    </div>

</body>

</html>