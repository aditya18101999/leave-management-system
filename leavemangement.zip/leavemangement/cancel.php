<?php
$conn = new mysqli("localhost", "root", "", "leavemanager");

$lid = $_GET['lid'];
$query = "DELETE FROM `leavetable` WHERE `lid`='$lid'";
$result = mysqli_query($conn, $query);
header('Location:checkstatus.php');
?>
