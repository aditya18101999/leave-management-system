<?php
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$designation = $_POST['designation'];
$dept=$_POST['dept'];


$conn = new mysqli("localhost", "root", "", "leavemanager");


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";



$sql = "INSERT INTO `user`(`username`, `password`, `email`, `designation`, `dept`) VALUES ('$username','$password','$email','$designation','$dept')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
header('Location: Employee.html');

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    header('Location: reg.php?error=username already exists.');
}

$conn->close();
?>