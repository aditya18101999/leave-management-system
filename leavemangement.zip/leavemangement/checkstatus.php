<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Leave manager</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="box">
        <p class="large bold upper">welcome
            <?php
            session_start();
            echo $_SESSION['username'];
            // echo $_SESSION['cusid'];
            ?>
        </p>

        <?php
        $uid = $_SESSION['uid'];

        $conn = new mysqli("localhost", "root", "", "leavemanager");
        $query = "SELECT * FROM `leavetable` WHERE uid = '$uid'";
        $result=mysqli_query($conn,$query);


        echo "<table ><tr><th> leave id </th><th>start date</th><th>number of days</th><th>reason</th><th>status</th><th>cancel</th></tr>";
        $countpt = mysqli_num_rows($result);

        // echo $cusid;


        for ($i = 0; $i < $countpt; $i++) {
            $row = mysqli_fetch_array($result);

            echo "<tr><td> " . $row['lid'] . " </td><td> " . $row['startdate'] . " </td><td>" . $row['numdays'] . "</td><td>" . $row['reason'] . "</td><td>" . $row['status'] . "</td><td><a href='cancel.php?lid=".$row['lid']."'><button class='button'>CANCEL</button></a></td></tr>";
        }



        echo "</table>";
        ?>



        </form>
    </div>
</body>

</html>