<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Leave manager</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="box">
        <p class="large bold upper">welcome
            <?php
            session_start();
            echo $_SESSION['username'];
            ?>
        </p>

        <?php
        $adminid = $_SESSION['adminid'];

        $conn = new mysqli("localhost", "root", "", "leavemanager");
        $query = "SELECT * FROM `leavetable` WHERE status = 'pending'";
        $result = mysqli_query($conn, $query);



        echo "<table ><tr><th> leave id </th><th> Applicant </th><th> designation </th><th> dept </th><th>start date</th><th>number of days</th><th>reason</th><th>status</th><th>Accept</th><th>Reject</th></tr>";
        $countpt = mysqli_num_rows($result);



        for ($i = 0; $i < $countpt; $i++) {
            $row = mysqli_fetch_array($result);
            $uid = $row['uid'];
            $queryuser = "SELECT * FROM `user` WHERE uid = '$uid'";
            $resultuser = mysqli_query($conn, $queryuser);
            $rowuser=mysqli_fetch_array($resultuser);


            echo "<tr><td> " . $row['lid'] . "</td><td> " . $rowuser['username'] ."</td><td> " . $rowuser['designation'] ."</td><td> " . $rowuser['dept'] ." </td><td> " . $row['startdate'] . " </td><td>" . $row['numdays'] . "</td><td>" . $row['reason'] . "</td><td>" . $row['status'] . "</td><td><a href='approve.php?lid=" . $row['lid'] . "'><button class='approve'>Approve</button></a></td>". "</td><td><a href='reject.php?lid=" . $row['lid'] . "'><button class='reject'>Reject</button></a></td></tr>";
        }



        echo "</table>";
        ?>
    </div>
</body>

</html>