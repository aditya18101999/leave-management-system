<?php
$startdate = $_POST['startdate'];
$numdays = $_POST['numdays'];
$reason = $_POST['reason'];
$status = "pending";
session_start();
$uid=$_SESSION['uid'];


$conn = new mysqli("localhost", "root", "", "leavemanager");


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";


$query="SELECT SUM(`numdays`) AS 'sumdays' FROM `leavetable` WHERE `uid`='$uid'";
$result=mysqli_query($conn,$query);
$row=mysqli_fetch_array($result);
$sumdays=$row['sumdays']+$numdays;
if ($sumdays>20) {
    header('Location:maxreached.php');
}


$sql = "INSERT INTO `leavetable`(`uid`, `startdate`, `numdays`, `reason`, `status`) VALUES ('$uid','$startdate','$numdays','$reason','$status')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
header('Location: logged.php');

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    header('Location: applyleave.php?error=error.');
}

$conn->close();
?>