<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Leave manager</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="box">
        <p class="large bold upper">welcome 
    <?php
        session_start();
        echo $_SESSION['username'];
        $uid=$_SESSION['uid'];
        $conn = new mysqli("localhost", "root", "", "leavemanager");




        $query="SELECT SUM(`numdays`) AS 'sumdays' FROM `leavetable` WHERE `uid`='$uid'";
        $result=mysqli_query($conn,$query);
        $row=mysqli_fetch_array($result);
        if ($row['sumdays']>20) {
            header('Location:maxreached.php');
        }





        
        // echo $_SESSION['cusid'];
        ?>
    </p>

        <div>
            <a href="applyleave.php"><button class="button">APPLY LEAVE</button></a>

            <br><br>
        </div>

        <div>
            <a href="checkstatus.php"><button class="button">CHECK STATUS</button></a>

            <br><br>
        </div>
         
        
    </div>
</body>
</html>