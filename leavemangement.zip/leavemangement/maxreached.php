<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Leave manager</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css?family=Lato:100i&display=swap" rel="stylesheet">
</head>
<body>
    <div class="box">
        <p class="large bold upper" style="font-family:  'Lato','Times New Roman' ,sans-serif;">Leave Management System 
   
    </p>
    <p class="large bold upper" style="font-family:  'Lato','Times New Roman' ,sans-serif;">maximum leaves reached
    
    </p>
    <p>

    </p>
       
         
        
    </div>
</body>
</html>