<?php
$username = $_POST['username'];
$password = $_POST['password'];


// Create connection
$conn = new mysqli("localhost", "root", "", "leavemanager"); 

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "SELECT * FROM `user` WHERE username = '$username'";


$result = mysqli_query($conn,$query);
$row = mysqli_fetch_array($result);

$passcode = $row['password'];


if ($passcode == $password){
    session_start();
    $_SESSION['username'] = $username;
    $_SESSION['uid'] = $row['uid'];

    header('Location: logged.php');
}
else{
    header('Location: login.php?error=Incorrect username/password.');
}

$conn->close();
?>