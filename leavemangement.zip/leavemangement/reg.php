<!DOCTYPE html>

<html>

<head>
    <title>Leave Manager</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="box">
        <div class="card">
            <h1 class="label">Registration Form</h1>
            <form action="reginsert.php" method="POST">
                <table>
                    <tr>
                        <p style="color:red;">
                            <?php
                            if (isset($_GET['error'])) {
                                $error = $_GET['error'];

                                echo $error;
                            }
                            ?>
                        </p>
                    </tr>
                    <tr>
                        <td>Username :</td>
                        <td><input type="text" name="username" required /></td>
                    </tr>
                    <tr>
                        <td>Password :</td>
                        <td><input type="password" name="password" required /></td>
                    </tr>
                    
                    <tr>
                        <td>Email :</td>
                        <td><input type="email" name="email" required /></td>
                    </tr>
                    <tr>
                        <td>Designation</td>
                        <td>
                            <input type="text" name="designation" required />
                        </td>
                    </tr>
                    <tr>
                        <td>Dept</td>
                        <td>
                            <input type="text" name="dept" required />
                        </td>
                    </tr>


                    </tr>
                    <tr>
                        <td></td>
                        <td><input class="button" type="submit" value="Submit" /></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>

</body>

</html>